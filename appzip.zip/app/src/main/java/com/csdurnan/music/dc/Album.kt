package com.csdurnan.music.dc

data class Album(
    val albumTitle: String,
    val artist: String,
    val songs: MutableList<Song>
    )
