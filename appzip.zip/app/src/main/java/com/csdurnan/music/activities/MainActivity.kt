package com.csdurnan.music.activities

import android.app.Service
import android.content.*
import android.database.Cursor
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.os.PersistableBundle
import android.service.controls.ControlsProviderService.TAG
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.csdurnan.music.ContentManagement
import com.csdurnan.music.R
import com.csdurnan.music.adapters.AllSongsAdapter
import com.csdurnan.music.databinding.ActivityMainBinding
import com.csdurnan.music.dc.Artist
import com.csdurnan.music.dc.Song
import com.csdurnan.music.utils.MediaPlayerService

class MainActivity : AppCompatActivity() {
    private lateinit var newRecyclerView : RecyclerView
    private lateinit var newArrayList : ArrayList<Artist>

    lateinit var artistTitle : Array<String>

    private lateinit var navController: NavController

    lateinit var player: MediaPlayerService
    lateinit var serviceConnection: ServiceConnection
    var serviceBound = false

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {

//        var songList: ArrayList<Song> = arrayListOf()
//
//        // Creates an instance of the ContentResolver. The contentResolver property is part of the 'Context' class
//        val resolver: ContentResolver = contentResolver
//        val uri =  android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
//        val cursor: Cursor? = resolver.query(uri, null, null, null, null)
//
//        when {
//            cursor == null -> {
//                // query failed
//                println("query failed")
//            }
//            !cursor.moveToFirst() -> {
//                println("no media on device")
//                // no media on device
//            }
//            else -> {
//                val idColumn: Int  = cursor.getColumnIndex(android.provider.MediaStore.Audio.Media._ID)
//                val titleColumn: Int = cursor.getColumnIndex(android.provider.MediaStore.Audio.Media.TITLE)
//                val albumColumn: Int = cursor.getColumnIndex(android.provider.MediaStore.Audio.Media.ALBUM)
//                val artistColumn: Int = cursor.getColumnIndex(android.provider.MediaStore.Audio.Media.ARTIST)
//                val cdTrackNumberColumn: Int = cursor.getColumnIndex(android.provider.MediaStore.Audio.Media.CD_TRACK_NUMBER)
//
//                do {
//                    val id = cursor.getLong(idColumn)
//                    val title = cursor.getString(titleColumn)
//                    val album = cursor.getString(albumColumn)
//                    val artist = cursor.getString(artistColumn)
//                    val cdTrackNumber = cursor.getString(cdTrackNumberColumn)
//
//                    songList.add(Song(id, title, album, artist, cdTrackNumber))
//                } while (cursor.moveToNext())
//
//            }
//        }
//        cursor?.close()
//        songList = ArrayList(songList.sortedBy { it.title })

//        var songsAllListRecyclerView : RecyclerView = findViewById(R.id.rv_songs_all_list)
//        songsAllListRecyclerView.layoutManager = LinearLayoutManager(this)
//        songsAllListRecyclerView.setHasFixedSize(true)
//        songsAllListRecyclerView.adapter = AllSongsAdapter(songList)
//        println(songList.size)




        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        var artistsButton = findViewById<LinearLayout>(R.id.ll_fragment_bottom_menu_artists)
        artistsButton.setOnClickListener {
            navController.navigate(R.id.allArtists)
        }

        var albumsButton = findViewById<LinearLayout>(R.id.ll_fragment_bottom_menu_albums)
        albumsButton.setOnClickListener {
            navController.navigate(R.id.allAlbums)
        }

        var songsButton = findViewById<LinearLayout>(R.id.ll_fragment_bottom_menu_songs)
        songsButton.setOnClickListener {
            navController.navigate(R.id.allSongs)
        }


        serviceConnection = object: ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                var binder: MediaPlayerService.LocalBinder = service as MediaPlayerService.LocalBinder
                player = binder.getService()
                serviceBound = true

                println("\n\n\nservice main activity\n\n\n")
                //Toast.makeText(this@MainActivity, "Service Bound", Toast.LENGTH_SHORT).show();
            }

            override fun onServiceDisconnected(p0: ComponentName?) {
                serviceBound = false
            }
        }


        val intent = Intent(this@MainActivity, MediaPlayerService::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        savedInstanceState.putBoolean("ServiceState", serviceBound)
        super.onSaveInstanceState(savedInstanceState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        serviceBound = savedInstanceState.getBoolean("ServiceState")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            unbindService(serviceConnection)
            player.stopSelf()
        }
    }

    fun playAudio(song: Song) {
        if (!serviceBound) {
            var playerIntent: Intent = Intent(this@MainActivity, MediaPlayerService::class.java)

            playerIntent.putExtra("MEDIA_URI", song)
            startService(playerIntent)
            bindService(playerIntent, serviceConnection, Context.BIND_AUTO_CREATE)
        } else {
            var broadcastIntent: Intent = Intent(Broadcast_PLAY_NEW_AUDIO)
            broadcastIntent.putExtra("MEDIA_URI", song)
            sendBroadcast(broadcastIntent)
        }
    }

    companion object {
        val Broadcast_PLAY_NEW_AUDIO = "com.csdurnan.music.PlayNewAudio"

    }
}