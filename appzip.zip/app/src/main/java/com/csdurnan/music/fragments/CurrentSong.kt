package com.csdurnan.music.fragments

import android.content.*
import android.database.Cursor
import android.graphics.Bitmap
import android.media.Image
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.csdurnan.music.ContentManagement
import com.csdurnan.music.R
import com.csdurnan.music.dc.Song
import com.csdurnan.music.utils.MediaPlayerService
import java.util.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [CurrentSong.newInstance] factory method to
 * create an instance of this fragment.
 */
class CurrentSong : Fragment() {
    private lateinit var serviceConnection: ServiceConnection
    lateinit var player: MediaPlayerService
    var serviceBound = false

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_current_song, container, false)
        val songId = arguments?.getLong("songId")
        var song = loadSong(songId)

        serviceConnection = object : ServiceConnection {
            @RequiresApi(Build.VERSION_CODES.Q)
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                val binder = service as MediaPlayerService.LocalBinder
                player = binder.getService()
                serviceBound = true

                // Start playing the song
                if (song != null) {
                    playAudio(song)

                    val pauseButton = view.findViewById<ImageView>(R.id.ivPlayButton)
                    pauseButton.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.stop, null))
                    pauseButton.setOnClickListener {

                        if (player.isPlaying()) {
                            player.pauseMedia()
                            pauseButton.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.play, null))
                        } else {
                            player.resumeMedia()
                            pauseButton.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.stop, null))
                        }
                    }

                    val prevButton = view.findViewById<ImageView>(R.id.ivRewindButton).setOnClickListener {
                        val bundle = Bundle()
                        bundle.putLong("songId", song.id - 1)

                        val current = CurrentSong()
                        current.arguments = bundle

                        val transaction =this@CurrentSong.parentFragmentManager.beginTransaction()
                        transaction.replace(R.id.nav_host_fragment, current)
                        transaction.commit()
                    }

                    val nextButton = view.findViewById<ImageView>(R.id.ivFastForwardButton).setOnClickListener {
                        val bundle = Bundle()
                        bundle.putLong("songId", song.id + 1)

                        val current = CurrentSong()
                        current.arguments = bundle

                        val transaction =this@CurrentSong.parentFragmentManager.beginTransaction()
                        transaction.replace(R.id.nav_host_fragment, current)
                        transaction.commit()
                    }
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                serviceBound = false
                Log.d("serviceConnection", "Not good")
            }
        }

        val intent = Intent(requireContext(), MediaPlayerService::class.java)
        var boo = requireContext().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        // Inflate the layout for this fragment
        return view
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun playAudio(song: Song) {
        if (serviceBound) {
            if (song != null) {
                // Use the existing MediaPlayerService instance
                player.setMedia(song)
                player.playMedia()

                // Update the seek bar and current time label
                val bar = view?.findViewById<SeekBar>(R.id.sbSongPositionBar)
                val currentTime = view?.findViewById<TextView>(R.id.tvSongCurrentTime)
                view?.findViewById<TextView>(R.id.tvSongTotalTime)?.text = timeLabel(song.duration)

                if (song.cover != null) {
                    view?.findViewById<ImageView>(R.id.ivSongImageView)?.setImageBitmap(song.cover)
                    view?.findViewById<ImageView>(R.id.ivSongImageView)?.scaleType = ImageView.ScaleType.FIT_CENTER;
                    view?.findViewById<TextView>(R.id.tvSongTitle)?.text = song.title
                    view?.findViewById<TextView>(R.id.tvArtistTitle)?.text = song.artist
                }

                bar?.max = song.duration

                val timer = Timer()
                timer.scheduleAtFixedRate(object : TimerTask() {
                    override fun run() {
                        activity?.runOnUiThread {
                            bar?.progress = player.currentPosition()
                            currentTime?.text = timeLabel(player.currentPosition())
                        }
                    }
                }, 0, 1000)

                bar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            player.seekTo(progress)
                            activity?.runOnUiThread {
                                if (currentTime != null) {
                                    currentTime.text = timeLabel(progress)
                                }
                            }
                        }
                    }

                    override fun onStartTrackingTouch(p0: SeekBar?) {
                    }

                    override fun onStopTrackingTouch(p0: SeekBar?) {
                    }

                })
            }
        }
    }

    private fun timeLabel(time: Int): String {
        var label = ""
        var min = time / 1000 / 60
        var sec = time / 1000 % 60

        label = "$min:"
        if (sec < 10) label += "0"
        label += sec

        return label
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            activity?.unbindService(serviceConnection)
            player.stopMedia()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun loadSong(songId: Long?): Song? {
        var contentResolver = context?.contentResolver
        var newSong: Song? = null

        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        // Creates an instance of the ContentResolver. The contentResolver property is part of the 'Context' class
        var cursor: Cursor? = contentResolver?.query(uri, null, "_ID = $songId", null, null)

        when {
            cursor == null          -> println("query failed")
            !cursor.moveToFirst()   -> println("no media on device")
            else                    -> {

                val idColumn: Int  = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val albumColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val artistColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val cdTrackNumberColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.CD_TRACK_NUMBER)
                val albumIdColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                val durationColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)

                do {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn)
                    val album = cursor.getString(albumColumn)
                    val artist = cursor.getString(artistColumn)
                    val cdTrackNumber = cursor.getInt(cdTrackNumberColumn)
                    val albumId = cursor.getLong(albumIdColumn)
                    val duration = cursor.getInt(durationColumn)

                    val trackUri =
                        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val cr = context?.contentResolver

                    var bm: Bitmap? = null
                    if (cr != null) {
                        bm = cr.loadThumbnail(trackUri, Size(2048, 2048), null)
                    }

                    newSong = Song(id, title, album, artist, cdTrackNumber, albumId, duration, bm)

                } while (cursor.moveToNext())
            }
        }
        cursor?.close()

        return newSong
    }

}