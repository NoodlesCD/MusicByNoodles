package com.csdurnan.music.adapters

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.RecyclerView
import com.csdurnan.music.R
import com.csdurnan.music.dc.Song
import com.csdurnan.music.fragments.CurrentSong

class AllSongsAdapter(private val songList: ArrayList<Song>, private val fragment: Fragment) : RecyclerView.Adapter<AllSongsAdapter.ViewHolder>() {
    /**
     * Provides a reference to the type of views that we will be using.
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val songName: TextView
        val artistName: TextView
        val image: ImageView
        val row: ConstraintLayout

        init {
            songName = view.findViewById(R.id.tv_songs_all_list_title)
            artistName = view.findViewById(R.id.tv_songs_all_list_artist)
            image = view.findViewById(R.id.iv_all_songs_row_image)
            row = view.findViewById(R.id.cl_all_songs_list_row)
        }
    }

    /**
     * RecyclerView calls this method when it needs to create a new ViewHolder.
     * This method creates and initializes a ViewHolder and its associated view.
     * It does not fill in the view's contents with any specific data.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.songs_all_list_row, parent, false)
        return ViewHolder(view)
    }

    /**
     * RecyclerView calls this method to get a size of a dataset.
     * Uses this to determine when there are no more items that can be displayed.
     */
    override fun getItemCount(): Int {
        return songList.size
    }

    /**
     * RecyclerView calls this method to associate a ViewHolder with data.
     * This method fetches appropriate data and uses it to fill in the layout.
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.songName.text = songList[position].title
        holder.artistName.text = songList[position].artist

        if (songList[position].cover != null) {
            holder.image.setImageBitmap(songList[position].cover)
        }

        holder.row.setOnClickListener {
            it.findNavController().navigate(R.id.currentSong)
            val bundle = Bundle()
            Log.d("1", songList[position].id.toString())
            bundle.putLong("songId", songList[position].id)

            val current = CurrentSong()
            current.arguments = bundle
            Log.d("2", current.arguments.toString())

            val transaction = fragment.parentFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_host_fragment, current)
            transaction.commit()

        }
    }
}