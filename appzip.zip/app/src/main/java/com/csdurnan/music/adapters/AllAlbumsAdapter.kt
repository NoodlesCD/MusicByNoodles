package com.csdurnan.music.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.csdurnan.music.R
import com.csdurnan.music.dc.Album
import com.csdurnan.music.dc.Artist

class AllAlbumsAdapter(private val albumsList : ArrayList<Album>) : RecyclerView.Adapter<AllAlbumsAdapter.ViewHolder>() {
    /**
     * Provides a reference to the type of views that we will be using.
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val albumName: TextView
        val artistName: TextView

        init {
            albumName = view.findViewById(R.id.tv_all_albums_row_title)
            artistName = view.findViewById(R.id.tv_all_albums_row_artist)
        }
    }

    /**
     * RecyclerView calls this method when it needs to create a new ViewHolder.
     * This method creates and initializes a ViewHolder and its associated view.
     * It does not fill in the view's contents with any specific data.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.all_albums_row, parent, false)
        return ViewHolder(itemView)
    }

    /**
     * RecyclerView calls this method to get a size of a dataset.
     * Uses this to determine when there are no more items that can be displayed.
     */
    override fun getItemCount(): Int {
        return albumsList.size
    }

    /**
     * RecyclerView calls this method to associate a ViewHolder with data.
     * This method fetches appropriate data and uses it to fill in the layout.
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.albumName.text = albumsList[position].albumTitle
        holder.artistName.text = albumsList[position].artist
    }
}