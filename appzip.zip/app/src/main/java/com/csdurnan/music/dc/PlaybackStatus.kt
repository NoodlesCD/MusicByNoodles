package com.csdurnan.music.dc

enum class PlaybackStatus {
    PLAYING,
    PAUSED
}