package com.csdurnan.music.dc

data class Artist(
    var artistTitle: String,
    var albums: MutableList<Album>,
    var songCount: Int
)