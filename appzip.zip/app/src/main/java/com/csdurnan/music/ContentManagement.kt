package com.csdurnan.music

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.annotation.Size
import androidx.core.graphics.decodeBitmap
import com.csdurnan.music.dc.Album
import com.csdurnan.music.dc.Artist
import com.csdurnan.music.dc.Song
import java.io.FileNotFoundException

@RequiresApi(Build.VERSION_CODES.Q)
class ContentManagement(contentResolver: ContentResolver) {
    var artistsList: MutableMap<String, Artist> = mutableMapOf()
    var albumsList: MutableMap<String, Album> = mutableMapOf()
    var songsList: MutableList<Song> = mutableListOf()

    init {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        // Creates an instance of the ContentResolver. The contentResolver property is part of the 'Context' class
        var cursor: Cursor? = contentResolver.query(uri, null, null, null, null)

        when {
            cursor == null -> {
                // query failed
                println("query failed")
            }
            !cursor.moveToFirst() -> {
                println("no media on device")
                // no media on device
            }
            else -> {
                val idColumn: Int  = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val albumColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val artistColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val cdTrackNumberColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.CD_TRACK_NUMBER)
                val albumIdColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                val durationColumn: Int = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)

                do {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn)
                    val album = cursor.getString(albumColumn)
                    val artist = cursor.getString(artistColumn)
                    val cdTrackNumber = cursor.getInt(cdTrackNumberColumn)
                    val albumId = cursor.getLong(albumIdColumn)
                    val duration = cursor.getInt(durationColumn)

                    val trackUri =
                        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val cr = contentResolver

                    var bm: Bitmap? = null
                    if (cr != null) {
                        try {
                            bm = cr.loadThumbnail(trackUri, android.util.Size(2048, 2048), null)
                        } catch (ex: FileNotFoundException) {

                        }

                    }

                    val newSong = Song(id, title, album, artist, cdTrackNumber, albumId, duration, bm)

                    if (artistsList[artist] == null) {
                        val newAlbum = mutableListOf(Album(album, artist, mutableListOf(newSong)))
                        artistsList[artist] = Artist(artist, newAlbum, 1)
                    } else {
                        var existingAlbum = false

                        for (i in artistsList.getValue(artist).albums.indices) {
                            if (artistsList.getValue(artist).albums[i].albumTitle == album) {
                                artistsList.getValue(artist).albums[i].songs.add(newSong)
                                existingAlbum = true
                                break
                            }
                        }

                        if (!existingAlbum) {
                            var newAlbum = Album(album, artist, mutableListOf(newSong))
                            artistsList.getValue(artist).albums.add(newAlbum)
                        }

                        artistsList.getValue(artist).songCount++
                    }

                    if (albumsList[album] == null) {
                        albumsList[album] = Album(album, artist, mutableListOf(newSong))
                    }

                    songsList.add(newSong)
                } while (cursor.moveToNext())

            }
        }
        cursor?.close()


    }

    val artists = ArrayList<Artist>(artistsList.values)
    val albums = ArrayList<Album>(albumsList.values)
    val songs = ArrayList<Song>(songsList)
}